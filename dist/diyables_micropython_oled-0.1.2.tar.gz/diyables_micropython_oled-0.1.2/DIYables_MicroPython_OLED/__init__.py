# DIYables_MicroPython_OLED/__init__.py
from .DIYables_MicroPython_OLED import OLED_SSD1306_I2C
